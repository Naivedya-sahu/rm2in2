#!/bin/bash
# inject_file_fast.sh - Fast batch injection using single SSH session
# Much faster than inject_file.sh (opens only one SSH connection)

set -e

if [ $# -lt 2 ]; then
    echo "Usage: inject_file_fast.sh <file.txt> <rm2_ip> [offset_x] [offset_y]"
    echo ""
    echo "Examples:"
    echo "  inject_file_fast.sh test.txt 10.11.99.1"
    echo "  inject_file_fast.sh test.txt 10.11.99.1 1000 500"
    echo ""
    exit 1
fi

TXT_FILE="$1"
RM2_IP="$2"
OFFSET_X="${3:-0}"
OFFSET_Y="${4:-0}"
FIFO_PATH="/tmp/lamp_inject"

if [ ! -f "$TXT_FILE" ]; then
    echo "Error: File not found: $TXT_FILE"
    exit 1
fi

echo "========================================"
echo "RM2 Fast Injection"
echo "========================================"
echo "File:      $TXT_FILE"
echo "Target:    $RM2_IP"
echo "Offset:    ($OFFSET_X, $OFFSET_Y)"
echo ""

# Count commands
TOTAL_LINES=$(wc -l < "$TXT_FILE")
echo "Commands:  $TOTAL_LINES"
echo ""

echo "Converting to PEN_* commands..."

# Convert M/D format to PEN_* commands
PEN_DOWN=0
{
    while IFS= read -r line; do
        CMD=$(echo "$line" | awk '{print $1}')
        X=$(echo "$line" | awk '{print $2}')
        Y=$(echo "$line" | awk '{print $3}')
        
        [ -z "$CMD" ] || [ -z "$X" ] || [ -z "$Y" ] && continue
        
        X=$((X + OFFSET_X))
        Y=$((Y + OFFSET_Y))
        
        if [ "$CMD" = "M" ]; then
            if [ $PEN_DOWN -eq 1 ]; then
                echo "PEN_UP"
                PEN_DOWN=0
            fi
        elif [ "$CMD" = "D" ]; then
            if [ $PEN_DOWN -eq 0 ]; then
                echo "PEN_DOWN $X $Y"
                PEN_DOWN=1
            else
                echo "PEN_MOVE $X $Y"
            fi
        fi
    done < "$TXT_FILE"
    
    if [ $PEN_DOWN -eq 1 ]; then
        echo "PEN_UP"
    fi
} > /tmp/inject_commands.tmp

COMMAND_COUNT=$(wc -l < /tmp/inject_commands.tmp)
echo "Generated: $COMMAND_COUNT PEN_* commands"
echo ""

# Estimate time
RATE=100
DURATION=$((COMMAND_COUNT / RATE))
MINUTES=$((DURATION / 60))
SECONDS=$((DURATION % 60))

echo "Estimated time: ${MINUTES}m ${SECONDS}s (at $RATE events/sec)"
echo ""

read -p "Ready to inject? Press Enter to continue, Ctrl+C to cancel..."
echo ""

echo "=============================================="
echo "IMPORTANT: Tap pen on RM2 screen NOW"
echo "=============================================="
echo ""
echo "Sending commands..."

# Send all commands in one SSH session (much faster!)
cat /tmp/inject_commands.tmp | ssh root@$RM2_IP "while IFS= read -r cmd; do echo \"\$cmd\" > $FIFO_PATH; done"

rm -f /tmp/inject_commands.tmp

echo ""
echo "=============================================="
echo "✓ Injection complete!"
echo "=============================================="
echo "Sent $COMMAND_COUNT commands"
echo ""
