#!/bin/bash
# inject_file.sh - Inject M/D format file to RM2
# Converts "M x y" and "D x y" to PEN_* commands

set -e

if [ $# -lt 2 ]; then
    echo "Usage: inject_file.sh <file.txt> <rm2_ip> [offset_x] [offset_y]"
    echo ""
    echo "Examples:"
    echo "  inject_file.sh test.txt 10.11.99.1"
    echo "  inject_file.sh test.txt 10.11.99.1 1000 500"
    echo ""
    exit 1
fi

TXT_FILE="$1"
RM2_IP="$2"
OFFSET_X="${3:-0}"
OFFSET_Y="${4:-0}"
FIFO_PATH="/tmp/lamp_inject"

if [ ! -f "$TXT_FILE" ]; then
    echo "Error: File not found: $TXT_FILE"
    exit 1
fi

echo "========================================"
echo "RM2 File Injection"
echo "========================================"
echo "File:      $TXT_FILE"
echo "Target:    $RM2_IP"
echo "Offset:    ($OFFSET_X, $OFFSET_Y)"
echo ""

# Count commands
TOTAL_LINES=$(wc -l < "$TXT_FILE")
echo "Commands:  $TOTAL_LINES"
echo ""

# Check if server is running
echo "Checking RM2 server status..."
STATUS=$(ssh root@$RM2_IP "/opt/rm2-inject/server.sh status 2>&1" | grep "Server:" || echo "NOT FOUND")

if echo "$STATUS" | grep -q "RUNNING"; then
    echo "✓ Server is running"
else
    echo "✗ Server not running"
    echo ""
    echo "Start server first:"
    echo "  ssh root@$RM2_IP '/opt/rm2-inject/server.sh start'"
    exit 1
fi

# Verify FIFO exists
echo "Checking FIFO..."
ssh root@$RM2_IP "[ -p $FIFO_PATH ] && echo '✓ FIFO exists' || echo '✗ FIFO missing'"
echo ""

# Estimate time
RATE=100  # events per second
DURATION=$((TOTAL_LINES / RATE))
MINUTES=$((DURATION / 60))
SECONDS=$((DURATION % 60))

echo "Estimated time: ${MINUTES}m ${SECONDS}s (at $RATE events/sec)"
echo ""

read -p "Ready to inject? Press Enter to continue, Ctrl+C to cancel..."
echo ""

echo "Injecting..."
echo "=============================================="
echo "IMPORTANT: Tap pen on RM2 screen to trigger injection"
echo "=============================================="
echo ""

# Convert M/D format to PEN_* commands and send
CURRENT_LINE=0
PEN_DOWN=0

while IFS= read -r line; do
    CURRENT_LINE=$((CURRENT_LINE + 1))
    
    # Progress indicator every 1000 lines
    if [ $((CURRENT_LINE % 1000)) -eq 0 ]; then
        PERCENT=$((CURRENT_LINE * 100 / TOTAL_LINES))
        echo "  Progress: $CURRENT_LINE / $TOTAL_LINES ($PERCENT%)"
    fi
    
    # Parse line: "M x y" or "D x y"
    CMD=$(echo "$line" | awk '{print $1}')
    X=$(echo "$line" | awk '{print $2}')
    Y=$(echo "$line" | awk '{print $3}')
    
    # Skip invalid lines
    [ -z "$CMD" ] || [ -z "$X" ] || [ -z "$Y" ] && continue
    
    # Apply offset
    X=$((X + OFFSET_X))
    Y=$((Y + OFFSET_Y))
    
    if [ "$CMD" = "M" ]; then
        # Move (pen up)
        if [ $PEN_DOWN -eq 1 ]; then
            # Lift pen first
            echo "PEN_UP" | ssh root@$RM2_IP "cat > $FIFO_PATH"
            PEN_DOWN=0
        fi
        # Move to new position (pen stays up)
        
    elif [ "$CMD" = "D" ]; then
        # Draw (pen down)
        if [ $PEN_DOWN -eq 0 ]; then
            # Put pen down at this position
            echo "PEN_DOWN $X $Y" | ssh root@$RM2_IP "cat > $FIFO_PATH"
            PEN_DOWN=1
        else
            # Move while pen is down
            echo "PEN_MOVE $X $Y" | ssh root@$RM2_IP "cat > $FIFO_PATH"
        fi
    fi
    
done < "$TXT_FILE"

# Lift pen at end
if [ $PEN_DOWN -eq 1 ]; then
    echo "PEN_UP" | ssh root@$RM2_IP "cat > $FIFO_PATH"
fi

echo ""
echo "=============================================="
echo "✓ Injection complete!"
echo "=============================================="
echo "Sent $TOTAL_LINES commands"
echo ""
