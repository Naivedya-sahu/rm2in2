# rm2fb Architecture Evolution Analysis

**Understanding what changed between versions and why**

---

## Architecture Timeline

### Version 2.15 → 3.5: Simple Direct Hooking

**Required Addresses:** 3-4

```cpp
const AddressInfo version_3_5_info = {
  InlinedFunction{ 0x59fd0, 0x5a0e8, 0x5b4c0 },  // createThreads
  SimpleFunction{ 0x53ff8 },                      // update
  SimpleFunction{ 0xb2f08 },                      // shutdownFn
};
```

**How It Works:**
- All framebuffer code embedded in xochitl
- Direct function hooks
- Simple memory replacement
- No separate library

**Limitation:** Every xochitl update changes internal structure significantly.

---

### Version 3.8: Transition Architecture

**Required Addresses:** 8 (different from 3.20!)

```cpp
const AddressInfo version_3_8_info = {
  SimpleFunction{ 0x6b3ed4 },        // createThreads
  SimpleFunction{ 0x6d0424 },        // update
  SimpleFunction{ 0x6b37f8 },        // shutdownFn
  (pthread_mutex_t*)0x1192e40,       // updateMutex
  (sem_t*)0x11921d8,                 // updateSemaphore  
  (pthread_mutex_t*)0x11921e0,       // vsyncMutex
  (pthread_cond_t*)0x1192208,        // vsyncCond
  (bool*)0x1192290,                  // globalInit
};
```

**How It Works:**
- Still embedded in xochitl
- Added complex threading model
- Synchronization primitives for thread safety
- More robust update mechanism

**Key Addition:** Mutex/semaphore for coordinating updates between threads.

---

### Version 3.20+: libqsgepaper Architecture

**Required Addresses:** 9 (completely different structure)

```cpp
const AddressInfo version_3_20_info = {
  // xochitl functions (hooks):
  .createThreads = SimpleFunction{ 0x73a3c0 },
  .update = SimpleFunction{ 0x7919c8 },
  .shutdownFn = SimpleFunction{ 0x739c80 },
  
  // NEW: libqsgepaper.so library offsets:
  .funcEPFramebufferSwtconUpdate = 0x38b58,
  .funcUpdate = 0x3ccdc,
  .funcLock = 0x3b6d8,
  .funcUnlock = 0x3ddc0,
  
  // Global state:
  .globalInit = (bool*)0x11ba2c0,
  .hasShutdown = (bool*)0x11b7478,
};
```

**Major Architecture Change:**

reMarkable extracted framebuffer logic into **separate library: libqsgepaper.so**

**Why This Matters:**
- xochitl now just **calls library functions**
- Library has more stable API between versions
- Library addresses change very little (< 0x100 bytes typically)
- xochitl addresses still change significantly (hundreds of KB)

**Server/Client Split:**

**Server Mode:** Calls libqsgepaper.so functions directly
```cpp
void initThreads() {
  auto* initialize = dlsym(libqsgepaper, "EPFramebufferSwtcon::initialize");
  // Hook malloc to redirect framebuffer allocation
  PreloadHook::hook<Malloc>(mallocHook);
  initialize();  // Call library directly
}

bool doUpdate(const UpdateParams& params) {
  lockFn.call<void>();
  updateFn.call<void>(&mappedParams);  // Call library
  unlockFn.call<void>();
}
```

**Client Mode:** Hooks xochitl calls via LD_PRELOAD
```cpp
bool installHooks(UpdateFn* newUpdate) {
  createThreads.hook((void*)createThreadsHook);  // Intercept
  update.hook((void*)newUpdate);                 // Redirect
  shutdownFn.hook((void*)shutdownHook);         // Intercept
}
```

---

## Critical Difference: What You Need to Find

### Scenario A: 3.24 Has libqsgepaper (Like 3.20)

**Test on RM2:**
```bash
ssh root@10.11.99.1 "ls -lh /usr/lib/libqsgepaper.so*"
# If exists → Use 3.20+ architecture
```

**Find 9 addresses:**

**In xochitl binary:**
1. createThreads (function) - Initialize framebuffer subsystem
2. update (function) - Main update dispatch
3. shutdownFn (function) - Cleanup on exit
4. globalInit (bool*) - Initialization state flag
5. hasShutdown (bool*) - Shutdown state flag

**In libqsgepaper.so library:**
6. funcEPFramebufferSwtconUpdate - Hardware update trigger
7. funcUpdate - Queue update operation
8. funcLock - Acquire update mutex
9. funcUnlock - Release update mutex

**Why library offsets?**
- rm2fb server mode needs to call library functions directly
- Offsets are relative to library base address
- Very stable between versions (±0x100 typically)

---

### Scenario B: 3.24 No libqsgepaper (Like 3.8)

**If library doesn't exist → Use 3.8 architecture**

**Find 8 addresses:**

**In xochitl binary only:**
1. createThreads (function)
2. update (function)
3. shutdownFn (function)
4. updateMutex (pthread_mutex_t*)
5. updateSemaphore (sem_t*)
6. vsyncMutex (pthread_mutex_t*)
7. vsyncCond (pthread_cond_t*)
8. globalInit (bool*)

**Why synchronization primitives?**
- All threading logic is in xochitl
- Need to coordinate with xochitl's update thread
- rm2fb hooks into existing mutexes

---

## Address Change Patterns

### Analyzing 3.20 → 3.22 → 3.23 Progression

**xochitl Functions (Large Shifts):**
```
Version    createThreads  update      shutdownFn
3.20.0     0x73a3c0      0x7919c8    0x739c80
3.22.0     0x6d2664      0x70c5c8    0x6d1ddc   (shifted -440KB)
3.23.0     0x717388      0x74a118    0x70fca0   (+280KB)
```

**Pattern:** Code additions/refactoring shift functions significantly.

**libqsgepaper.so Functions (Tiny Shifts):**
```
Version    EPFBUpdate  funcUpdate  funcLock   funcUnlock
3.20.0     0x38b58     0x3ccdc     0x3b6d8    0x3ddc0
3.22.0     0x38b18     0x3ccb4     0x3b698    0x3dd98   (-0x40 typical)
3.23.0     0x38b00     0x3ccac     0x3b690    0x3dd90   (-0x18 typical)
```

**Pattern:** Library API is stable, only minor adjustments.

**Global Variables (Section-Based Shifts):**
```
Version    globalInit    hasShutdown
3.20.0     0x11ba2c0    0x11b7478
3.22.0     0x13f6380    0x13f20c8    (+2.3MB - .bss section grew)
3.23.0     0x130dd00    0x1309584    (moved but similar offset)
```

**Pattern:** Variables shift based on .bss/.data section size changes.

---

## Waveform Mode Mapping Evolution

**Why this matters:** Screen update quality depends on correct waveform mapping.

### Internal Waveform Modes

| Description | 2.15 | 3.3 | 3.5 | 3.6+ |
|-------------|------|-----|-----|------|
| DU (pen)    | 0    | 0   | 0   | 1    |
| GL16 (init) | 2    | 2   | 2   | 2    |
| GC16 (ui)   | 1    | 3   | 3   | 3    |
| A2 (pan)    | 3    | 8/0 | 8/0 | 6    |

**Version 3.20 Mapping:**
```cpp
switch(waveform) {
  case WAVEFORM_MODE_INIT:  return 2;
  case WAVEFORM_MODE_DU:    return 1;
  case WAVEFORM_MODE_GC16:  return 2;
  case WAVEFORM_MODE_GL16:  return 3;
  case WAVEFORM_MODE_A2:    return 6;
}
```

**Observation for 3.24:**
If using 3.20+ architecture, waveform mapping is likely identical or very similar. This is already implemented in rm2fb code - you just need correct addresses.

---

## Function Criticality Assessment

### ✅ REQUIRED - Cannot Work Without

**createThreads:**
```cpp
int createThreadsHook(ImageInfo* info) {
  const auto& fb = SharedFB::getInstance();
  info->data = fb.mem.get();  // CRITICAL: Redirect framebuffer pointer
  return 0;
}
```
**Why:** Without this, apps draw to wrong memory location. Screen stays blank.

**update:**
```cpp
bool updateHook(const UpdateParams& params) {
  // Intercept screen refresh commands
  // Route to rm2fb-aware applications
}
```
**Why:** Without this, screen never updates. Apps draw but nothing displays.

**globalInit:**
```cpp
if (*globalInit == false) {
  doInitialization();
  *globalInit = true;
}
```
**Why:** Prevents double initialization which causes crashes.

---

### ❓ PROBABLY REQUIRED - High Risk to Skip

**Library functions (if 3.20+ arch):**
- funcUpdate, funcLock, funcUnlock
- Server mode directly drives hardware via library
- Skipping these = server mode won't work

**Synchronization primitives (if 3.8 arch):**
- updateMutex, vsyncMutex, etc.
- Required for thread-safe updates
- Skipping = race conditions, corruption

---

### ⚠️ POSSIBLY OPTIONAL - Low Risk to Skip

**shutdownFn:**
```cpp
void shutdownHook() {
  puts("HOOK: Shutdown called!");
  // Does minimal cleanup
}
```
**Impact if skipped:** Memory leak on exit, but xochitl exit cleans up anyway.

**hasShutdown:**
```cpp
*addrs.hasShutdown = true;  // Set once, never read in newer code
```
**Impact if skipped:** Might be redundant with globalInit.

**Recommendation:** Find them anyway. Time difference is minimal, risk elimination is valuable.

---

## Expected Address Ranges for 3.24

Based on 3.23 patterns:

```
xochitl binary:
  Functions:      0x600000 - 0x800000
  Global vars:    0x1200000 - 0x1400000

libqsgepaper.so (if exists):
  Functions:      0x30000 - 0x40000
  (Small library, compact address space)
```

Use these as sanity checks in Ghidra. If you find createThreads at 0x00001234, it's wrong.

---

## Key Takeaway

**The architecture you need depends on whether libqsgepaper.so exists in 3.24.**

Check this FIRST before starting Ghidra work. The entire approach changes based on this.
