# rm2fb Port to 3.24 - Project Decision

**Date:** 2024-12-05  
**Project:** rm2in2 - reMarkable 2 Component Library  
**Decision:** Port rm2fb to firmware 3.24.0.147 instead of using direct injection

---

## Context

Originally working with direct input injection method (lamp-style) for rm2in2 project. This approach has proven limitations:
- Coordinate transformation problems (skewed geometry)
- Curves render incorrectly
- Tedious SVG-to-pen-command conversion pipeline
- Manual triggering via space tap required
- Not suitable for production workflow

## The Decision

**Pivot to framebuffer-based approach** by porting rm2fb to firmware 3.24.0.147.

### Why This Makes Sense

1. **Direct pixel manipulation** - No coordinate transformation hell
2. **Proper UI framework** - Can use rmkit/simple.cpy for rapid development
3. **Render once, done** - No conversion pipeline needed
4. **Production-ready** - This is how real RM2 apps work
5. **Component library requires UI** - Need proper button/selection framework

### What rm2fb Enables

- **harmony app** - Low-latency drawing with procedural brushes (reference implementation)
- **rmkit simple.cpy** - Rapid UI development framework
- **Component manipulation** - Proper drag/drop/select functionality
- **All rmkit apps** - Terminal, calculator, games, etc.

## Technical Approach

### Phase 1: Determine Architecture
Check if 3.24 uses libqsgepaper.so (3.20+ architecture) or embedded framebuffer (3.8 architecture).

```bash
ssh root@10.11.99.1 "ls -lh /usr/lib/libqsgepaper.so*"
```

### Phase 2: Reverse Engineering with Ghidra
Extract xochitl and library binaries, analyze in Ghidra to find required addresses.

**If libqsgepaper exists (3.20+ arch):** 9 addresses needed  
**If no libqsgepaper (3.8 arch):** 8 addresses needed

### Phase 3: Create Version File
Implement Version3.24.cpp with found addresses.

### Phase 4: Testing
- Build rm2fb libraries
- Test in safe virtual environment first
- Deploy to device with LD_PRELOAD (non-destructive)
- Verify with harmony app

### Phase 5: Component Library Development
Once rm2fb works, build component library using rmkit/simple.cpy.

## Risk Assessment

**Brick Risk:** Near zero
- Using LD_PRELOAD (doesn't modify system files)
- Can always SSH in and remove library
- Worst case: xochitl crashes, reboot fixes it

**Time Investment:** 20-30 hours total
- Ghidra analysis: 6-10 hours
- Virtual environment setup: 2-3 hours
- Testing and debugging: 3-5 hours
- Component library development: 8-12 hours

**Alternative Cost:** Continuing with injection method would require solving:
- Coordinate transformation (unknown time)
- Smooth curve generation (complex)
- Conversion pipeline optimization (tedious)
- Still wouldn't have proper UI framework

## Expected Outcome

Working rm2fb on 3.24.0.147 enabling:
1. Full rmkit app compatibility
2. Component library with proper UI
3. Faster development iteration
4. Production-ready circuit design workflow

---

## Key Insight

**"Better doing all this task I should draw directly by hand"** - This was the trigger. If the injection method is harder than manual drawing, it's the wrong approach. Framebuffer is the right architectural layer for this problem.
