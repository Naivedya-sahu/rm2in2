# CONTINUATION PROMPT: rm2fb Port for reMarkable 2 Firmware 3.24

**Use this to resume development in future conversations**

---

## Project Status: Ready to Begin Ghidra Work

**Current Phase:** Pre-implementation  
**Next Action:** Architecture detection and Ghidra analysis  
**Objective:** Port rm2fb to firmware 3.24.0.147 to enable framebuffer-based component library development

---

## Context Summary

I'm developing **rm2in2**, a circuit design system for reMarkable 2 tablet (RM2). The goal is to create an electronic component symbol library with drag-and-drop functionality for circuit schematics.

**Previous Approach (ABANDONED):**
- Direct input injection via /dev/input/event1 (lamp-style)
- Synthetic pen strokes for drawing
- **Problems:** Coordinate transformation issues, skewed curves, tedious conversion pipeline
- **Conclusion:** Not production-viable - "better to draw by hand"

**New Approach (CURRENT):**
- Port rm2fb (framebuffer library) to firmware 3.24.0.147
- Use rmkit/simple.cpy for rapid UI development
- Direct pixel manipulation instead of pen command injection
- Proper component library with selection/drag/drop functionality

---

## Technical Environment

**Device:** reMarkable 2 tablet  
**Firmware:** 3.24.0.147 (beta)  
**OS:** Codex Linux (no package managers, no Python)  
**Development Machine:** Windows + WSL  
**Working Directory:** `C:\Users\NAVY\Documents\Github\rm2in2`

**Key Resources:**
- `resources/repos/rM2-stuff/` - Contains rm2fb source code
- `resources/repos/rmkit/` - Contains harmony app and simple.cpy framework
- Lamp tool: Confirmed working on 3.24.0.147

---

## Decision Rationale

**Why rm2fb instead of continuing injection method:**

1. **Framebuffer is the right abstraction layer**
   - Direct pixel manipulation (no coordinate hell)
   - Render once, done (no conversion pipeline)
   - Proper UI framework available (rmkit)
   - This is how production apps work

2. **Enables component library properly**
   - Need button/selection frameworks
   - Need drag-and-drop interaction
   - Need proper rendering quality
   - rmkit/simple.cpy provides all this

3. **Time investment is justified**
   - 20-30 hours for rm2fb port
   - Alternative: Indefinite time fixing injection problems
   - Framebuffer unlocks entire rmkit ecosystem
   - Production-ready solution vs. perpetual workarounds

4. **Low brick risk**
   - Using LD_PRELOAD (non-destructive)
   - Can always SSH and remove library
   - Virtual environment testing first
   - Proven safe approach from community

---

## Architecture Understanding

### rm2fb Evolution

**Version 2.15-3.5:** Simple direct hooking (3-4 addresses)  
**Version 3.8:** Added threading/synchronization (8 addresses)  
**Version 3.20+:** Split into libqsgepaper.so library (9 addresses)

### Critical First Step: Architecture Detection

**MUST determine which architecture 3.24 uses:**

```bash
ssh root@10.11.99.1 "ls -lh /usr/lib/libqsgepaper.so*"
```

**If library exists** → Use 3.20+ architecture (9 addresses)  
**If no library** → Use 3.8 architecture (8 addresses)

This determines everything that follows.

---

## What Needs to Be Found

### Scenario A: 3.20+ Architecture (With libqsgepaper)

**9 addresses required:**

**In xochitl binary:**
1. createThreads (function) - Initializes framebuffer, redirects to shared memory
2. update (function) - Main screen update dispatcher
3. shutdownFn (function) - Cleanup on exit
4. globalInit (bool*) - Prevents double initialization
5. hasShutdown (bool*) - Shutdown state flag

**In libqsgepaper.so library:**
6. funcEPFramebufferSwtconUpdate - Hardware update trigger
7. funcUpdate - Queue update operation
8. funcLock - Acquire update mutex
9. funcUnlock - Release update mutex

### Scenario B: 3.8 Architecture (No libqsgepaper)

**8 addresses required:**

**In xochitl binary only:**
1. createThreads (function)
2. update (function)
3. shutdownFn (function)
4. updateMutex (pthread_mutex_t*)
5. updateSemaphore (sem_t*)
6. vsyncMutex (pthread_mutex_t*)
7. vsyncCond (pthread_cond_t*)
8. globalInit (bool*)

---

## Known Reference Points (Version 3.23)

**If 3.24 uses 3.20+ architecture, these are your reference:**

```cpp
// xochitl functions:
createThreads: 0x717388
update:        0x74a118
shutdownFn:    0x70fca0

// Library offsets:
funcEPFramebufferSwtconUpdate: 0x38b00
funcUpdate:    0x3ccac
funcLock:      0x3b690
funcUnlock:    0x3dd90

// Globals:
globalInit:    0x130dd00
hasShutdown:   0x1309584
```

**Pattern Observations:**
- xochitl functions: Shift hundreds of KB between versions
- Library offsets: Very stable (±0x100 typically)
- Global variables: Shift based on .bss section growth

---

## Ghidra Analysis Strategy

### Phase 1: Architecture Detection (5 min)
Check for libqsgepaper.so on device

### Phase 2: Binary Extraction (10 min)
```bash
scp root@10.11.99.1:/usr/bin/xochitl ~/ghidra_work/xochitl_3.24.0.147
scp root@10.11.99.1:/usr/lib/libqsgepaper.so.1.0.0 ~/ghidra_work/  # If exists
ssh root@10.11.99.1 "readelf -n /usr/bin/xochitl | grep 'Build ID'" > build_id.txt
```

### Phase 3: Ghidra Import (20 min)
- Import xochitl_3.24.0.147
- Language: ARM:LE:32:v7 (ARMv7 Little Endian 32-bit)
- Run full analysis
- Open Symbol Tree, Decompiler, Strings windows

### Phase 4: Address Finding (6-10 hours)
See GHIDRA_CHECKLIST.md for detailed search methods

**Key search techniques:**
- **String anchoring:** Search for "EPFramebufferSwtcon::initialize"
- **Constant search:** Look for 1404 (framebuffer width)
- **Pattern matching:** Identify function structures
- **Cross-referencing:** Follow function calls
- **Comparison:** Use 3.23 as reference

### Phase 5: Verification (1-2 hours)
- Static verification in Ghidra (signature checks, cross-references)
- Create safe test program (read-only memory checks)
- Test in virtual environment before device deployment

### Phase 6: Implementation (2-3 hours)
- Create Version3.24.cpp with found addresses
- Update Version.h and Version.cpp
- Build rm2fb libraries
- Test with harmony app

---

## Important Patterns for Ghidra

### ARM Assembly Patterns to Recognize

**Loading global variable:**
```asm
ldr     r3, =0x130dd00    ; Load address
ldrb    r3, [r3]          ; Load byte
cmp     r3, #0            ; Compare to 0
beq     not_initialized   ; Branch if false
```

**Switch statement (waveform mapping):**
```asm
cmp     r0, #8              ; Compare value
bhi     default_case        ; Branch if > 8
ldr     pc, [pc, r0, lsl #2]  ; Jump table
```

**Function call:**
```asm
bl      0x717388    ; Branch with Link (call function)
```

### Verification Signatures

**createThreads should contain:**
```c
void* createThreads(ImageInfo* info) {
  void* buffer = malloc(0x503580);  // Specific size
  info->width = 1404;               // Display width
  info->height = 1872;              // Display height
  info->stride = 1404;
  info->data = buffer;
  EPFramebufferSwtcon::initialize();
  return info;
}
```

**update should contain:**
```c
bool update(UpdateParams* params) {
  int waveform = params->waveform;
  switch(waveform) {  // Waveform mapping
    case 0: ... break;
    case 1: ... break;
    // etc.
  }
  pthread_mutex_lock(mutex);
  EPFramebufferSwtcon::update(...);
  pthread_mutex_unlock(mutex);
  return true;
}
```

---

## Expected Address Ranges

**Sanity checks for found addresses:**

```
xochitl binary:
  Functions:      0x600000 - 0x800000
  Global vars:    0x1200000 - 0x1400000

libqsgepaper.so (if exists):
  Functions:      0x30000 - 0x40000
```

If an address is wildly outside these ranges, it's probably wrong.

---

## Development Workflow After rm2fb Port

**Once rm2fb is working:**

1. **Test with harmony app** (drawing/interaction reference)
2. **Study harmony code structure** (component concepts)
3. **Create simple test with rmkit/simple.cpy**
4. **Build minimal component library:**
   - Single component type (resistor)
   - Place at position
   - Detect tap/select
   - Implement drag
5. **Iterate and expand:**
   - Add more component types
   - Implement rotation
   - Add wire routing
   - Build full circuit editor

---

## Critical Reminders

**Before starting Ghidra:**
✅ Check architecture (libqsgepaper exists?)  
✅ Extract build ID (needed for version detection)  
✅ Create address tracking spreadsheet  

**During Ghidra analysis:**
✅ Verify each address with multiple methods  
✅ Cross-reference to confirm correctness  
✅ Compare with 3.23 reference patterns  
✅ Document findings as you go  

**Before device deployment:**
✅ Test addresses in virtual environment  
✅ Use LD_PRELOAD (non-destructive)  
✅ Keep SSH watchdog running  
✅ Document recovery procedure  

**Never:**
❌ Modify system files directly  
❌ Skip verification steps  
❌ Deploy untested addresses to device  
❌ Work without backup/recovery plan  

---

## Files Created in This Session

**Documentation Set:** `/mnt/user-data/outputs/rm2fb_port_documentation/`

1. **PROJECT_DECISION.md** - Why we're doing this, rationale, risk assessment
2. **ARCHITECTURE_ANALYSIS.md** - Technical evolution, what changed between versions
3. **GHIDRA_CHECKLIST.md** - Practical step-by-step address finding guide
4. **CONTINUATION_PROMPT.md** - This file (context for future conversations)

---

## How to Resume in Next Conversation

**Provide Claude with:**

```
I'm continuing the rm2fb port to 3.24 for my reMarkable 2 component library project.

Last session we decided to port rm2fb instead of continuing with input injection.
I have the documentation in rm2fb_port_documentation/.

Current status:
[Describe what you've accomplished - architecture detection, addresses found, etc.]

Next I need help with:
[Describe specific issue or next step]
```

**Claude will have context from:**
- userMemories (project background, technical decisions)
- Documentation files (detailed technical reference)
- This continuation prompt (current status)

---

## Key Technical Insights from This Session

1. **Injection method was fundamentally limited** - Coordinate transformation, curve quality, conversion pipeline complexity made it impractical.

2. **Framebuffer is the right abstraction** - Direct pixel manipulation eliminates entire class of problems. This is how production apps work.

3. **Architecture matters** - 3.20+ split framebuffer into separate library (libqsgepaper.so). Must detect which architecture 3.24 uses before starting.

4. **Library addresses are stable** - If using 3.20+ arch, library offsets change by <0x100 between versions. This makes porting easier than expected.

5. **Not all addresses equally critical** - createThreads, update, globalInit are essential. shutdownFn and hasShutdown might be optional (but safer to include).

6. **Ghidra decompiler is key** - Don't need to be ARM expert. Use pseudo-C code, search by patterns and strings, cross-reference to verify.

7. **Testing strategy prevents bricks** - Virtual environment first, LD_PRELOAD (non-destructive), incremental testing. Brick risk is near zero with proper procedure.

8. **Time investment is justified** - 20-30 hours for rm2fb vs. indefinite time fixing injection method. Framebuffer unlocks entire ecosystem (rmkit, harmony, etc.).

---

## Project Goal (Keep in Mind)

**End goal:** Electronic component library for circuit design on reMarkable 2

**Requirements:**
- Drag-and-drop components (resistors, capacitors, ICs, etc.)
- Wire routing between components
- Selection/manipulation/rotation
- Export to standard formats (SVG, KiCad, etc.)
- Fast, responsive interaction
- Production-ready quality

**Why rm2fb enables this:**
- Proper UI framework (rmkit/simple.cpy)
- Fast rendering (direct framebuffer)
- Event handling (touch/pen)
- Reference implementation (harmony app)
- No coordinate transformation issues
- No conversion pipeline overhead

---

## Success Criteria

**Phase 1 (rm2fb port):** COMPLETE when harmony app runs on 3.24  
**Phase 2 (minimal test):** Single component placement with tap detection  
**Phase 3 (prototype):** Basic component library with drag functionality  
**Phase 4 (production):** Full circuit editor with export capability  

Currently at: **Phase 0 → Phase 1** (starting Ghidra work)

---

## Questions to Ask in Next Session

Depending on progress, you might need help with:

- ❓ Interpreting Ghidra decompiler output
- ❓ Verifying found addresses are correct
- ❓ Debugging address-finding issues
- ❓ Creating Version3.24.cpp file
- ❓ Setting up virtual environment for testing
- ❓ Troubleshooting rm2fb build issues
- ❓ Debugging runtime crashes
- ❓ Starting component library development

---

**Ready to resume. Next action: Architecture detection on RM2.**
