# rm2fb Port Documentation - Index & Quick Reference

**Complete documentation set for porting rm2fb to reMarkable 2 firmware 3.24.0.147**

---

## Documentation Files

### 📋 [PROJECT_DECISION.md](PROJECT_DECISION.md)
**Read this first**  
Why we pivoted from input injection to framebuffer approach.
- Context and rationale
- Risk assessment
- Time investment justification
- Expected outcomes

### 🔧 [ARCHITECTURE_ANALYSIS.md](ARCHITECTURE_ANALYSIS.md)
**Technical deep dive**  
Understanding rm2fb evolution and what changed between versions.
- Version 2.15 → 3.5: Simple hooking
- Version 3.8: Threading model
- Version 3.20+: libqsgepaper split
- Address change patterns
- Waveform mode mapping

### ✅ [GHIDRA_CHECKLIST.md](GHIDRA_CHECKLIST.md)
**Practical work guide**  
Step-by-step instructions for finding addresses in Ghidra.
- Binary extraction
- Ghidra setup
- Address finding methods
- Verification procedures
- ARM assembly patterns
- Common mistakes to avoid

### 🔄 [CONTINUATION_PROMPT.md](CONTINUATION_PROMPT.md)
**For future conversations**  
Context to resume development with Claude in new conversations.
- Current project status
- Technical environment
- What's been accomplished
- Next steps
- Key insights

---

## Quick Start Guide

### Step 1: Architecture Detection (5 minutes)
```bash
ssh root@10.11.99.1 "ls -lh /usr/lib/libqsgepaper.so*"
```
- ✅ **Library exists** → Need 9 addresses (3.20+ architecture)
- ❌ **No library** → Need 8 addresses (3.8 architecture)

### Step 2: Binary Extraction (10 minutes)
```bash
mkdir -p ~/ghidra_work/rm2fb_3.24
cd ~/ghidra_work/rm2fb_3.24
scp root@10.11.99.1:/usr/bin/xochitl ./xochitl_3.24.0.147
scp root@10.11.99.1:/usr/lib/libqsgepaper.so.1.0.0 ./  # If exists
ssh root@10.11.99.1 "readelf -n /usr/bin/xochitl | grep 'Build ID'" > build_id.txt
```

### Step 3: Ghidra Analysis (6-10 hours)
See [GHIDRA_CHECKLIST.md](GHIDRA_CHECKLIST.md) for detailed instructions.

### Step 4: Implementation (2-3 hours)
Create `Version3.24.cpp` with found addresses.

### Step 5: Testing (3-5 hours)
Virtual environment → Safe device testing → Full deployment

---

## Addresses Required by Architecture

### If Using 3.20+ Architecture (libqsgepaper exists)

| # | Address Type | Location | Purpose |
|---|--------------|----------|---------|
| 1 | createThreads | xochitl | Initialize framebuffer |
| 2 | update | xochitl | Screen update dispatcher |
| 3 | shutdownFn | xochitl | Cleanup on exit |
| 4 | globalInit | xochitl | Init state flag (bool*) |
| 5 | hasShutdown | xochitl | Shutdown flag (bool*) |
| 6 | EPFBUpdate | libqsgepaper | Hardware trigger |
| 7 | funcUpdate | libqsgepaper | Queue update |
| 8 | funcLock | libqsgepaper | Mutex lock |
| 9 | funcUnlock | libqsgepaper | Mutex unlock |

### If Using 3.8 Architecture (no libqsgepaper)

| # | Address Type | Location | Purpose |
|---|--------------|----------|---------|
| 1 | createThreads | xochitl | Initialize framebuffer |
| 2 | update | xochitl | Screen update dispatcher |
| 3 | shutdownFn | xochitl | Cleanup on exit |
| 4 | updateMutex | xochitl | Update lock (pthread_mutex_t*) |
| 5 | updateSemaphore | xochitl | Update signal (sem_t*) |
| 6 | vsyncMutex | xochitl | VSync lock (pthread_mutex_t*) |
| 7 | vsyncCond | xochitl | VSync condition (pthread_cond_t*) |
| 8 | globalInit | xochitl | Init state flag (bool*) |

---

## Expected Address Ranges (Sanity Check)

```
xochitl binary:
  Functions:      0x600000 - 0x800000
  Global vars:    0x1200000 - 0x1400000

libqsgepaper.so (if exists):
  Functions:      0x30000 - 0x40000
```

If addresses fall wildly outside these ranges, verify in Ghidra.

---

## Reference Addresses (Version 3.23)

**Use these as comparison points:**

```cpp
// xochitl functions:
createThreads: 0x717388
update:        0x74a118
shutdownFn:    0x70fca0
globalInit:    0x130dd00
hasShutdown:   0x1309584

// libqsgepaper offsets:
funcEPFramebufferSwtconUpdate: 0x38b00
funcUpdate:    0x3ccac
funcLock:      0x3b690
funcUnlock:    0x3dd90
```

---

## Key Search Methods in Ghidra

### Finding createThreads
1. **String search:** "EPFramebufferSwtcon::initialize"
2. **Constant search:** 1404 (framebuffer width)
3. **Pattern:** Function that allocates 0x503580 bytes

### Finding update
1. **From createThreads:** Often nearby in symbol table
2. **Pattern:** Switch statement for waveform mapping
3. **Pattern:** Calls mutex lock/unlock

### Finding globalInit
1. **From createThreads:** Boolean checked before init
2. **Memory Map:** .bss section around 0x130dd00
3. **Pattern:** ldr/ldrb/cmp sequence in ARM assembly

### Finding Library Functions
1. **Symbol search:** "EPFramebufferSwtcon::update"
2. **Inside EPFBUpdate:** Look for lock/unlock/queue calls
3. **Offset check:** All within ±0x5000 of EPFBUpdate

---

## Verification Checklist

**Before declaring an address "found":**

✅ Function signature makes sense (correct parameters)  
✅ Contains expected constants (1404, 1872, 0x503580)  
✅ Address in valid memory range  
✅ Cross-references exist and make sense  
✅ Function size is reasonable (not 50 or 5000 bytes)  
✅ Compared with 3.23 reference structure  

**Runtime verification:**
✅ Test with read-only program first  
✅ Verify in virtual environment  
✅ Deploy with LD_PRELOAD (non-destructive)  

---

## Development Timeline

### Phase 0: Preparation ✓
- [x] Architecture analysis
- [x] Documentation creation
- [x] Reference material compiled

### Phase 1: Ghidra Analysis (Current)
- [ ] Architecture detection
- [ ] Binary extraction
- [ ] Address finding
- [ ] Verification

**Estimated:** 6-10 hours

### Phase 2: Implementation
- [ ] Create Version3.24.cpp
- [ ] Update Version.h/cpp
- [ ] Build rm2fb
- [ ] Virtual environment testing

**Estimated:** 2-3 hours

### Phase 3: Device Testing
- [ ] Deploy to RM2
- [ ] Test with harmony
- [ ] Verify stability
- [ ] Debug issues

**Estimated:** 3-5 hours

### Phase 4: Component Library
- [ ] Study harmony code
- [ ] Create minimal test
- [ ] Build component library
- [ ] Production integration

**Estimated:** 8-12 hours

**Total Project Time:** 20-30 hours

---

## Critical Success Factors

1. ✅ **Determine architecture first** - Everything depends on this
2. ✅ **Verify each address thoroughly** - One wrong address = crashes
3. ✅ **Test incrementally** - Virtual env → Safe deploy → Full test
4. ✅ **Document findings** - Track addresses in spreadsheet
5. ✅ **Have recovery plan** - LD_PRELOAD is non-destructive, can always remove

---

## Common Pitfalls to Avoid

❌ **Starting Ghidra before architecture check**  
   → Waste time looking for wrong addresses

❌ **Trusting first match without verification**  
   → Wrong address = crash on device

❌ **Skipping virtual environment testing**  
   → Risk device stability unnecessarily

❌ **Modifying system files directly**  
   → Potential for actual bricking

❌ **Not documenting as you go**  
   → Lose track of what worked/didn't work

---

## When to Ask for Help

**Ghidra-related:**
- Can't find a specific address after 2+ hours
- Decompiler output is confusing
- Multiple candidates, unsure which is correct
- ARM assembly is unclear

**Implementation-related:**
- Build errors in rm2fb
- Virtual environment setup issues
- Deployment problems
- Runtime crashes on device

**Architecture-related:**
- Unsure which architecture 3.24 uses
- Found addresses don't match expected patterns
- Reference addresses seem wrong

---

## Project Files Location

**Main project:** `C:\Users\NAVY\Documents\Github\rm2in2`

**Key directories:**
- `resources/repos/rM2-stuff/` - rm2fb source
- `resources/repos/rmkit/` - harmony and simple.cpy
- `Rm2/` - Server-side injection code (previous approach)
- `Rm2in2/` - Client tools and testing

**New for this phase:**
- `~/ghidra_work/rm2fb_3.24/` - Binaries for analysis
- Ghidra project: `rm2fb_3.24.gpr`

**Documentation:**
- `/mnt/user-data/outputs/rm2fb_port_documentation/` - This doc set

---

## Success Looks Like

**Phase 1 Complete:**
- ✅ All required addresses found
- ✅ Verified in Ghidra with cross-references
- ✅ Documented in spreadsheet
- ✅ Version3.24.cpp created

**Phase 2 Complete:**
- ✅ rm2fb libraries built successfully
- ✅ No compilation errors
- ✅ Version detection working

**Phase 3 Complete:**
- ✅ harmony app runs on 3.24
- ✅ Drawing works smoothly
- ✅ No crashes or artifacts
- ✅ Device stable

**Phase 4 Complete:**
- ✅ Component library functional
- ✅ Drag-and-drop working
- ✅ Production-ready quality
- ✅ Circuit design workflow streamlined

---

## Additional Resources

**reMarkable 2 Specifications:**
- Display: 1404×1872 (portrait)
- E-ink: Carta 1200
- Digitizer: Wacom EMR
- CPU: ARM Cortex-A7 (32-bit ARMv7)
- OS: Codex Linux

**Development Tools:**
- Ghidra: ARM decompiler/disassembler
- cross-compiler: arm-linux-gnueabihf-g++
- SSH: Direct device access
- evtest: Input event monitoring
- GDB: Runtime debugging

**Community Resources:**
- rM2-stuff repository (rm2fb source)
- rmkit repository (app framework)
- reMarkable wiki (hardware specs)
- Awesome-reMarkable list

---

## Final Reminders

**Before starting:**
1. Check architecture (libqsgepaper exists?)
2. Extract binaries and build ID
3. Create tracking spreadsheet
4. Read GHIDRA_CHECKLIST.md

**During work:**
1. Verify each address with multiple methods
2. Document findings continuously
3. Compare with 3.23 reference
4. Take breaks (Ghidra work is intense)

**Before deployment:**
1. Test in virtual environment
2. Use LD_PRELOAD (safe method)
3. Keep SSH connection open
4. Have recovery plan ready

**Remember:**
- Brick risk is near zero with proper procedure
- Time investment is justified vs. alternatives
- Framebuffer unlocks entire ecosystem
- This is the right technical approach

---

**Ready to begin. First action: Architecture detection.**

```bash
ssh root@10.11.99.1 "ls -lh /usr/lib/libqsgepaper.so*"
```
