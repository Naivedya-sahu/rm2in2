# Ghidra Address Finding Checklist for 3.24

**Practical step-by-step guide for reverse engineering rm2fb addresses**

---

## PRE-GHIDRA: Architecture Detection

**CRITICAL: Do this first to determine which addresses you need**

```bash
# Connect to RM2
ssh root@10.11.99.1

# Test 1: Does libqsgepaper exist?
ls -lh /usr/lib/libqsgepaper.so*

# Test 2: Does xochitl link to it?
ldd /usr/bin/xochitl | grep qsgepaper

# Test 3: Extract build ID (needed for version detection)
readelf -n /usr/bin/xochitl | grep "Build ID"
# Save this output - you'll need it later
```

**Result determines your path:**
- ✅ libqsgepaper exists → **Find 9 addresses** (3.20+ architecture)
- ❌ No libqsgepaper → **Find 8 addresses** (3.8 architecture)

---

## Phase 1: Binary Extraction

```bash
# Create work directory
mkdir -p ~/ghidra_work/rm2fb_3.24
cd ~/ghidra_work/rm2fb_3.24

# Extract xochitl
scp root@10.11.99.1:/usr/bin/xochitl ./xochitl_3.24.0.147

# If libqsgepaper exists, extract it too
scp root@10.11.99.1:/usr/lib/libqsgepaper.so.1.0.0 ./

# Get build ID
ssh root@10.11.99.1 "readelf -n /usr/bin/xochitl | grep 'Build ID'" > build_id.txt
```

---

## Phase 2: Ghidra Setup

### Import xochitl

1. Open Ghidra
2. **File → New Project → Non-Shared Project**
3. Name: `rm2fb_3.24`
4. **Import File** → Select `xochitl_3.24.0.147`
5. Format: **ELF** (auto-detected)
6. Language: **ARM:LE:32:v7** (ARMv7 Little Endian 32-bit)
7. Click **OK**
8. **"Analyze now?"** → **YES**
9. Accept all default analyzers
10. **Wait 5-15 minutes** for analysis to complete

### Open Essential Windows

Once analysis completes:
- **Window → Symbol Tree** (symbol browser)
- **Window → Decompiler** (pseudo-C code)
- **Window → Defined Strings** (string search)
- **Window → Memory Map** (section viewer)

---

## Phase 3: Address Tracking Spreadsheet

**Create this BEFORE starting searches:**

```
| Item                          | Address    | Status | Confidence | Verification Notes    |
|-------------------------------|------------|--------|------------|-----------------------|
| xochitl::createThreads        | 0x??????   | TODO   | -          |                       |
| xochitl::update               | 0x??????   | TODO   | -          |                       |
| xochitl::shutdownFn           | 0x??????   | TODO   | -          |                       |
| xochitl::globalInit           | 0x??????   | TODO   | -          |                       |
| xochitl::hasShutdown (opt)    | 0x??????   | TODO   | -          |                       |
| libqsgepaper::EPFBUpdate      | 0x??????   | TODO   | -          | (If library exists)   |
| libqsgepaper::funcUpdate      | 0x??????   | TODO   | -          | (If library exists)   |
| libqsgepaper::funcLock        | 0x??????   | TODO   | -          | (If library exists)   |
| libqsgepaper::funcUnlock      | 0x??????   | TODO   | -          | (If library exists)   |
```

---

## Finding Addresses: 3.20+ Architecture (With libqsgepaper)

### 🎯 Address 1: xochitl::createThreads

**Search Method 1: String Anchoring**
```
1. Search → For Strings... (Ctrl+Shift+E)
2. Search: "EPFramebufferSwtcon::initialize"
3. Find: "_ZN19EPFramebufferSwtcon10initializeEv"
4. Double-click string
5. Right-click → References → Show References to Address
6. Look for function that calls this
7. That function (or its caller) is likely createThreads
```

**Search Method 2: Pattern Recognition**
```
1. Search → Memory... (Search → For Scalars)
2. Search for decimal: 1404
   (This is framebuffer width constant)
3. Look for function containing:
   - Sets width = 1404
   - Sets height = 1872
   - Sets stride = 1404
   - Calls malloc(0x503580)
```

**Verification Checklist:**
```c
// In decompiler, should see:
void* FUN_0x?????? (ImageInfo* param_1) {
  ✓ Allocates 0x503580 bytes (framebuffer size)
  ✓ Sets param_1->width = 1404
  ✓ Sets param_1->height = 1872
  ✓ Sets param_1->stride = 1404
  ✓ Calls EPFramebufferSwtcon::initialize()
  
  return param_1;
}
```

**Recording Address:**
```
1. Look at top of decompiler: "FUN_00717388"
2. Address is: 0x717388
3. Right-click function → Rename → "createThreads"
4. Update spreadsheet: 0x717388, Status: FOUND, Confidence: HIGH
5. Add verification note: "Matches pattern, sets 1404x1872, calls initialize"
```

**Expected Range:** 0x600000 - 0x800000

---

### 🎯 Address 2: xochitl::update

**Search Method 1: Follow createThreads**
```
1. createThreads is often paired with update
2. In Symbol Tree, look at nearby functions
3. Look for function called frequently throughout code
```

**Search Method 2: Pattern Recognition**
```
Look for function with:
1. Switch/case statement (waveform mode mapping)
2. Mutex lock/unlock calls
3. Takes UpdateParams structure
4. Calls EPFramebufferSwtcon::update
```

**Verification Checklist:**
```c
// Should look like:
bool FUN_0x?????? (UpdateParams* params) {
  ✓ Takes update parameters (rect, waveform)
  ✓ Has switch statement mapping waveform values
  ✓ Calls pthread_mutex_lock or similar
  ✓ Calls EPFramebufferSwtcon::actualUpdate
  ✓ Calls pthread_mutex_unlock
  
  return true;
}
```

**ARM Pattern to Recognize:**
```asm
; Switch statement in ARM assembly:
cmp     r0, #8              ; Compare waveform value
bhi     default_case        ; Branch if out of range
ldr     pc, [pc, r0, lsl #2]  ; Jump table
```

**Expected Range:** 0x700000 - 0x800000

---

### 🎯 Address 3: xochitl::shutdownFn

**Search Method 1: String Search**
```
1. Search → For Strings...
2. Search: "shutdown" or "cleanup"
3. Look for framebuffer-related cleanup
```

**Search Method 2: Paired Function**
```
1. Found createThreads at address X
2. Look for corresponding destructor
3. Often named similarly or nearby in symbol table
```

**Verification Checklist:**
```c
// Should look like:
void FUN_0x?????? (void) {
  ✓ Frees framebuffer memory
  ✓ Destroys mutexes (pthread_mutex_destroy)
  ✓ Calls EPFramebufferSwtcon::shutdown
  ✓ Sets shutdown flag
}
```

**Expected Range:** 0x600000 - 0x800000

---

### 🎯 Address 4: xochitl::globalInit

**Search Method 1: Cross-Reference from createThreads**
```
1. Open createThreads in decompiler
2. Look for boolean variable checked before initialization:
   if (globalInit == false) {
       doInitialization();
       globalInit = true;
   }
3. Click on variable name
4. Right-click → Go To → Address
```

**Search Method 2: Memory Map Analysis**
```
1. Window → Memory Map
2. Go to .bss section (uninitialized globals)
3. Based on 3.23: around 0x130dd00
4. Look for bool (1 byte) referenced by createThreads
```

**ARM Pattern to Recognize:**
```asm
; Loading global bool:
ldr     r3, =0x130dd00    ; Load address into register
ldrb    r3, [r3]          ; Load byte from address
cmp     r3, #0            ; Compare to 0 (false)
beq     not_initialized   ; Branch if equal

; Setting global bool:
ldr     r3, =0x130dd00    ; Load address
mov     r2, #1            ; Load value 1 (true)
strb    r2, [r3]          ; Store byte
```

**Verification Steps:**
```
1. Found address: 0x130dd00
2. Right-click → Data → byte (define as bool)
3. Right-click → References → Show References To
4. Should see:
   ✓ Written in createThreads (set true)
   ✓ Read in update/shutdown (check state)
5. Label: Right-click → Label → "globalInit"
```

**Expected Range:** 0x1200000 - 0x1400000

---

### 🎯 Address 5: xochitl::hasShutdown (Optional)

**Search Method 1: From shutdownFn**
```
1. Open shutdownFn in decompiler
2. Look for boolean set to true at end
3. Example: hasShutdown = true;
4. Click variable → Go To Address
```

**Search Method 2: Near globalInit**
```
1. Found globalInit at 0x130dd00
2. In 3.23: hasShutdown = globalInit - 0x477C
3. Check nearby addresses: globalInit ± 0x10000
4. Look for another bool referenced by shutdown
```

**Expected Range:** Near globalInit (±50KB typically)

---

### 🎯 Addresses 6-9: libqsgepaper.so Functions

**Import Library into Ghidra:**
```
1. File → Import File → libqsgepaper.so.1.0.0
2. Language: ARM:LE:32:v7 (same as xochitl)
3. Analyze: YES
4. Wait for analysis
```

**Address 6: funcEPFramebufferSwtconUpdate**
```
Method 1: Symbol Search
1. Window → Symbol Tree
2. Filter: "update" or "EPFramebuffer"
3. Look for: _ZN19EPFramebufferSwtcon6updateE...
4. Double-click → Note address at top

Method 2: Command Line
# On Linux/WSL:
objdump -T libqsgepaper.so.1.0.0 | grep -i epframebuffer
# Shows exported symbols with addresses
```

**Verification:**
```c
// Should be method with signature like:
void EPFramebufferSwtcon::update(
    QRect rect,       // Screen region
    int pixelMode,    // Color mode  
    int waveformMode  // Update mode
) {
  ✓ Validates rect bounds
  ✓ Configures hardware registers
  ✓ Triggers EPD controller
}
```

**Address 7-9: funcUpdate, funcLock, funcUnlock**
```
Combined Search:
1. Already found EPFramebufferSwtcon::update
2. Look at its decompiled code
3. Inside, look for:
   
   pthread_mutex_lock(&updateMutex);     // This is funcLock
   queueUpdate(params);                  // This is funcUpdate
   pthread_mutex_unlock(&updateMutex);   // This is funcUnlock

4. Click each function call → note addresses

Alternative: Symbol Tree
1. Filter: "lock" → Find pthread_mutex_lock or wrapper
2. Filter: "unlock" → Find pthread_mutex_unlock
3. Filter: "queue" or "schedule" → Find update queuing
```

**Offset Verification:**
```cpp
// From 3.23 reference:
funcEPFramebufferSwtconUpdate: 0x38b00
funcUpdate:                    0x3ccac  (offset: +0x41AC)
funcLock:                      0x3b690  (offset: +0x2B90)
funcUnlock:                    0x3dd90  (offset: +0x5290)

// Your 3.24 addresses should have similar offset patterns
// All within ±0x5000 of EPFBUpdate
```

**Expected Range (all library functions):** 0x30000 - 0x40000

---

## Finding Addresses: 3.8 Architecture (No libqsgepaper)

**If libqsgepaper doesn't exist, use this path instead:**

### Find These 8 Addresses:

1. **createThreads** - Same as 3.20+ method above
2. **update** - Same as 3.20+ method above
3. **shutdownFn** - Same as 3.20+ method above
4. **updateMutex** (pthread_mutex_t*)
5. **updateSemaphore** (sem_t*)
6. **vsyncMutex** (pthread_mutex_t*)
7. **vsyncCond** (pthread_cond_t*)
8. **globalInit** (bool*)

**Finding Synchronization Primitives:**

```
Method 1: From update function
1. Open update function in decompiler
2. Look for pthread_mutex_lock call
3. First argument is address of mutex
4. Example: pthread_mutex_lock(0x1192e40);
5. Address 0x1192e40 is updateMutex

Method 2: Symbol/Data Search
1. Window → Data Type Manager
2. Search for: pthread_mutex_t
3. Window → Memory Map → .bss section
4. Look for mutex-sized structures (40 bytes typically)
5. Cross-reference to find which is used by update

Method 3: Known Patterns from 3.8
Reference addresses:
  updateMutex:     0x1192e40
  updateSemaphore: 0x11921d8
  vsyncMutex:      0x11921e0
  vsyncCond:       0x1192208
  
These are clustered together in .bss
Look for similar clustering in 3.24
```

---

## Verification: How to Know If Addresses Are Correct

### Static Verification (In Ghidra)

**Check 1: Function Signature**
```c
// Function should make sense
createThreads(ImageInfo* info) {
  info->width = 1404;   // ✅ Known constant
  // Not:
  info->width = 73829;  // ❌ Wrong
}
```

**Check 2: Address in Valid Range**
```
Functions:
✅ 0x717388 - In .text section, executable
❌ 0x00001234 - Too low, likely wrong
❌ 0x99999999 - Out of range

Globals:
✅ 0x130dd00 - In .bss section
❌ 0x717388 - This is .text, not data
```

**Check 3: Cross-References**
```
1. Right-click address → References → Find References
2. Should see:
   ✅ Multiple calls from other functions
   ✅ Makes sense in context
   
   ❌ No references - probably wrong
   ❌ Only one reference - suspicious
```

**Check 4: Compare Function Size**
```
Based on 3.23:
createThreads: ~200-300 bytes
update: ~500-800 bytes
shutdownFn: ~100-200 bytes

If your function is:
❌ 50 bytes - Too small, probably wrong
❌ 5000 bytes - Too large, probably wrong
✅ 250 bytes - Reasonable
```

### Safe Runtime Verification

**Create test program that reads (doesn't modify):**

```cpp
// verify_addresses.cpp
#include <stdio.h>
#include <dlfcn.h>

void check_readable(void* addr, const char* name) {
    if (addr == NULL) {
        printf("[FAIL] %s: NULL\n", name);
        return;
    }
    
    unsigned char* bytes = (unsigned char*)addr;
    printf("[OK] %s: 0x%p (", name, addr);
    for (int i = 0; i < 4; i++) {
        printf("%02x ", bytes[i]);
    }
    printf(")\n");
}

int main() {
    // Test your found addresses
    bool* globalInit = (bool*)0x130dd00;  // Your address
    check_readable(globalInit, "globalInit");
    
    // Add other addresses
    
    return 0;
}
```

**Deploy and test:**
```bash
# Compile for ARM
arm-linux-gnueabihf-g++ verify_addresses.cpp -o verify -ldl

# Copy to RM2
scp verify root@10.11.99.1:/tmp/

# Run (SAFE - only reads)
ssh root@10.11.99.1 "/tmp/verify"
```

**Expected output:**
```
[OK] globalInit: 0x130dd00 (00 00 00 00)
[OK] createThreads: 0x717388 (45 e9 2d e9)
```

---

## Common Mistakes to Avoid

❌ **Using decompiled variable names as real names**
```
Ghidra shows: "iVar1" - This is not the real variable name
```

❌ **Confusing offset with absolute address**
```
Library offset: 0x38b00 (relative to library base)
NOT absolute address: 0x00038b00
```

❌ **Searching in wrong binary**
```
xochitl addresses: Only in xochitl binary
Library offsets: Only in libqsgepaper.so
Don't mix them up
```

❌ **Not verifying architecture first**
```
Must check for libqsgepaper.so BEFORE starting Ghidra
Different architectures need different addresses
```

---

## Ghidra Keyboard Shortcuts

```
G            → Go to address
Ctrl+Shift+E → Search strings
Ctrl+Shift+F → Find references
L            → Rename/label
;            → Add comment
Ctrl+E       → Edit function signature
Ctrl+L       → Clear cache (if Ghidra stuck)
```

---

## ARM Register Quick Reference

```
r0-r3   → Function arguments & return value
r4-r11  → Local variables (preserved across calls)
r13(sp) → Stack pointer
r14(lr) → Return address (link register)
r15(pc) → Program counter
```

---

## Next Steps After Finding All Addresses

1. **Create Version3.24.cpp** with found addresses
2. **Update Version.h** to declare version
3. **Update Version.cpp** with build ID detection
4. **Build rm2fb libraries**
5. **Test in virtual environment**
6. **Deploy to device**

See PROJECT_DECISION.md for deployment strategy.

---

## Time Estimates

**Per Address (If experienced with Ghidra):**
- createThreads: 30-60 min
- update: 30-60 min
- shutdownFn: 15-30 min
- globalInit: 15-30 min
- hasShutdown: 15-30 min
- Library functions (all 4): 30-45 min

**Total:** 6-10 hours for all addresses

**If learning Ghidra:** Add 5-8 hours for learning curve

**Testing/debugging:** Add 3-5 hours

**Grand total:** 15-25 hours for complete working port
